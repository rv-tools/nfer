package gov.nasa.jpl.nfer.statistics

import breeze.linalg.DenseMatrix
import gov.nasa.jpl.nfer.UnitSpec

/**
 * Created by seanmk on 1/7/16.
 */
class LinearDiscriminantAnalysisTest extends UnitSpec {
  trait Iris {
    val iris = IrisData.loadDataFrame("iris.data").normalize
    val lda = new LinearDiscriminantAnalysis[(Int, String)]
    lda.train(iris)
  }

  it should "compute the correct W matrix" in new Iris {
    val testMatrix = new DenseMatrix[Double](4, 2,
      Array(-0.1498, -0.1482, 0.8511, 0.4808,
        0.0095, 0.3272, -0.5748, 0.75))

    val testW = lda.w(::, 0 to 1)

    for (row <- 0 until testMatrix.rows) {
      for (col <- 0 until testMatrix.cols) {
        testW(row, col) shouldBe testMatrix(row, col) +- 0.0001
      }
    }
  }

  ignore should "correctly transform the data" in new Iris {
    // who knows what order the test data is in, so sort everything
    val testAgainst = IrisData.loadDataFrame("iris_lda.data").getMatrix.sortBy((pairs) => pairs(0))
    val transformed = lda.reduce(iris, 2).getMatrix.sortBy((pairs) => pairs(0))

    testAgainst.length shouldBe 150
    transformed.length shouldBe 150

    for (row <- testAgainst.indices) {
      testAgainst(row).length shouldBe 2
      transformed(row).length shouldBe 2

      transformed(row)(0) shouldBe testAgainst(row)(0) +- 0.015
      transformed(row)(1) shouldBe testAgainst(row)(1) +- 0.015
    }
  }
}

