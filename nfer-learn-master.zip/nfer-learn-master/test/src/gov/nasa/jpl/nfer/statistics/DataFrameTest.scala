package gov.nasa.jpl.nfer.statistics

import gov.nasa.jpl.nfer.UnitSpec
import gov.nasa.jpl.nfer.lang.TestEvent

/**
 * Created by seanmk on 12/3/15.
 */
class DataFrameTest extends UnitSpec {
  val eventName = "TEST_ONE"
  val eventName2 = "TEST_TWO"
  val eventName3 = "TEST_THREE"
  
  trait Frame {
    val data = new DataFrame[TestEvent]()
    val rowEvent = TestEvent(eventName, 10.0)

    val testEvent = TestEvent(eventName, 1.0)
    val testEvent2 = TestEvent(eventName, 2.0)
    val testEvent3 = TestEvent(eventName2, 3.0)
    val items = List(testEvent, testEvent2, testEvent3)
  }
  
  trait Frame2 {
    val rowEvent2 = TestEvent(eventName, 20.0)
    
    val testEvent4 = TestEvent(eventName, 4.0)
    val testEvent5 = TestEvent(eventName3, 5.0)
    val items2 = List(testEvent4, testEvent5)
  }

  trait Populated extends Frame with Frame2 {
    data.addOrUpdateRow[TestEvent](rowEvent, items.iterator, (event) => event.name, new CountValue())
    data.addOrUpdateRow[TestEvent](rowEvent2, items2.iterator, (event) => event.name, new CountValue())

    val row = data.getRowValues(rowEvent)
    val row2 = data.getRowValues(rowEvent2)
    val vector = data.getVector(rowEvent)
    val vector2 = data.getVector(rowEvent2)
  }

  it should "split events into dimensions by name" in new Frame {
    data.addOrUpdateRow[TestEvent](rowEvent, items.iterator, (event) => event.name, new CountValue())
    val row = data.getRowValues(rowEvent)

    row.keys.size shouldBe 2
    row(eventName) shouldBe 2.0
    row(eventName2) shouldBe 1.0
  }

  it should "split events into dimensions by timestamp" in new Frame {
    data.addOrUpdateRow[TestEvent](rowEvent, items.iterator, (event) => event.start.toString, new CountValue())
    val row = data.getRowValues(rowEvent)

    row.keys.size shouldBe 3
    row(testEvent.start.toString) shouldBe 1.0
    row(testEvent2.start.toString) shouldBe 1.0
    row(testEvent3.start.toString) shouldBe 1.0
  }

  it should "set values to max timestamp" in new Frame {
    data.addOrUpdateRow[TestEvent](rowEvent, items.iterator, (event) => event.name, new MaxFieldValue("start"))
    val row = data.getRowValues(rowEvent)

    row.keys.size shouldBe 2
    row(eventName) shouldBe 2.0
    row(eventName2) shouldBe 3.0
  }

  it should "keep track of dimension names" in new Frame with Frame2 {
    data.addOrUpdateRow[TestEvent](rowEvent, items.iterator, (event) => event.name, new CountValue())
    data.addOrUpdateRow[TestEvent](rowEvent2, items2.iterator, (event) => event.name, new CountValue())
    val dimensions = data.getDimensionTable

    dimensions.length shouldBe 3
    dimensions(0) shouldBe eventName
    dimensions(1) shouldBe eventName2
    dimensions(2) shouldBe eventName3
  }

  it should "add dimensions to an existing row" in new Frame with Frame2 {
    data.addOrUpdateRow[TestEvent](rowEvent, items.iterator, (event) => event.name, new CountValue())
    val row = data.getRowValues(rowEvent)

    row.keys.size shouldBe 2
    row(eventName) shouldBe 2.0
    row(eventName2) shouldBe 1.0

    data.addOrUpdateRow[TestEvent](rowEvent, items2.iterator, (event) => event.start.toString, new MaxFieldValue("start"))
    val updated = data.getRowValues(rowEvent)

    updated.keys.size shouldBe 4
    updated(eventName) shouldBe 2.0
    updated(eventName2) shouldBe 1.0
    updated(testEvent4.start.toString) shouldBe 4.0
    updated(testEvent5.start.toString) shouldBe 5.0
  }

  it should "set correct dimension names" in new Populated {
    row.keys.size shouldBe 2
    row(eventName) shouldBe 2.0
    row(eventName2) shouldBe 1.0

    row2.keys.size shouldBe 2
    row2(eventName) shouldBe 1.0
    row2(eventName3) shouldBe 1.0
  }

  it should "create dense vectors" in new Populated {
    vector.length shouldBe 3
    vector(0) shouldBe 2.0
    vector(1) shouldBe 1.0
    vector(2) shouldBe 0.0

    vector2.length shouldBe 3
    vector2(0) shouldBe 1.0
    vector2(1) shouldBe 0.0
    vector2(2) shouldBe 1.0
  }

  it should "filter out rows without data" in new Frame with Frame2 {
    data.addOrUpdateRow[TestEvent](rowEvent, items.iterator, (event) => event.name, new CountValue())
    data.addOrUpdateRow[TestEvent](rowEvent2, List.empty[TestEvent].iterator, (event) => event.name, new CountValue())

    val vectors = data.getMatrix
    vectors.length shouldBe 2

    val nonEmpty = data.nonEmpty.getMatrix
    nonEmpty.length shouldBe 1
  }

  it should "normalize data" in new Populated {
    val norm = data.normalize.getVector(rowEvent)
    val norm2 = data.normalize.getVector(rowEvent2)

    norm.length shouldBe 3
    norm(0) shouldBe 0.7071067811865475
    norm(1) shouldBe 0.0
    norm(2) shouldBe 0.0

    norm2.length shouldBe 3
    norm2(0) shouldBe -0.7071067811865475
    norm2(1) shouldBe 0.0
    norm2(2) shouldBe 0.0
  }

  it should "make all data non-negative" in new Populated {
    val nonNeg = data.normalize.nonNegative.getVector(rowEvent)
    val nonNeg2 = data.normalize.nonNegative.getVector(rowEvent2)

    nonNeg.length shouldBe 3
    nonNeg(0) shouldBe 1.414213562373095
    nonNeg(1) shouldBe 0.0
    nonNeg(2) shouldBe 0.0

    nonNeg2.length shouldBe 3
    nonNeg2(0) shouldBe 0.0
    nonNeg2(1) shouldBe 0.0
    nonNeg2(2) shouldBe 0.0
  }
}
