package gov.nasa.jpl.nfer.statistics

import breeze.linalg.DenseMatrix
import gov.nasa.jpl.nfer.UnitSpec

/**
 * Created by seanmk on 1/4/16.
 */
class PrincipalComponentAnalysisTest extends UnitSpec {
  trait Iris {
    val iris = IrisData.loadDataFrame("iris.data").normalize
    val pca = new PrincipalComponentAnalysis[(Int, String)]
    pca.train(iris)
  }

  it should "compute the correct W matrix" in new Iris {
    val testMatrix = new DenseMatrix[Double](4, 2,
      Array(0.52237162, -0.26335492, 0.58125401,0.56561105,
            -0.37231836, -0.92555649, -0.02109478, -0.06541577))

    val testW = pca.w(::, 0 to 1)

    for (row <- 0 until testMatrix.rows) {
      for (col <- 0 until testMatrix.cols) {
        testW(row, col) shouldBe testMatrix(row, col) +- 0.0001
      }
    }
  }

  it should "correctly transform the data" in new Iris {
    // who knows what order the test data is in, so sort everything
    val testAgainst = IrisData.loadDataFrame("iris_pca.data").getMatrix.sortBy((pairs) => pairs(0))
    val transformed = pca.reduce(iris, 2).getMatrix.sortBy((pairs) => pairs(0))

    testAgainst.length shouldBe 150
    transformed.length shouldBe 150

    for (row <- testAgainst.indices) {
      testAgainst(row).length shouldBe 2
      transformed(row).length shouldBe 2

      //println(s"${transformed(row)(0)}, ${testAgainst(row)(0)}")
      //println(s"${transformed(row)(1)}, ${testAgainst(row)(1)}")

      transformed(row)(0) shouldBe testAgainst(row)(0) +- 0.015
      transformed(row)(1) shouldBe testAgainst(row)(1) +- 0.015
    }
  }
}
