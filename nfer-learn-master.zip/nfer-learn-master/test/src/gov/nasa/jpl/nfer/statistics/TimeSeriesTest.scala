package gov.nasa.jpl.nfer.statistics

import gov.nasa.jpl.nfer.UnitSpec

/**
 * Created by seanmk on 12/9/15.
 */
class TimeSeriesTest extends UnitSpec {
  trait TestSeries {
    val series = new TimeSeries
    series.add(20, 10)
    series.add(35, 15)
    series.add(36, 20)
    series.add(45, 25)
  }

  trait TestEqualPeriod {
    val s1 = new TimeSeries
    s1.add(10, 3.0)
    s1.add(20, 4.5)
    s1.add(30, 6.0)

    val s2 = new TimeSeries
    s2.add(50, 2.0)
    s2.add(60, 5.0)
    s2.add(70, 8.0)
  }

  trait TestNotCorrelated {
    val s3 = new TimeSeries
    s3.add(72, 33.3)
    s3.add(80, 10.0)
    s3.add(93, 20.0)
    s3.add(108, 15.0)
    s3.add(120, 22.2)
  }

  it should "sample at even intervals with the right values" in new TestSeries {
    val sampled = series.sampleFrom(10, 40, 10)

    sampled.length shouldBe 5
    sampled(0) shouldBe 0
    sampled(1) shouldBe 10
    sampled(2) shouldBe 10
    sampled(3) shouldBe 20
    sampled(4) shouldBe 25
  }

  it should "sample only the first part of the series" in new TestSeries {
    val sampled = series.sampleFrom(5, 20, 5)

    sampled.length shouldBe 5
    sampled(0) shouldBe 0
    sampled(1) shouldBe 0
    sampled(2) shouldBe 0
    sampled(3) shouldBe 10
    sampled(4) shouldBe 10
  }

  it should "sample only the last part of the series" in new TestSeries {
    val sampled = series.sampleFrom(35, 15, 5)

    sampled.length shouldBe 4
    sampled(0) shouldBe 15
    sampled(1) shouldBe 20
    sampled(2) shouldBe 25
    sampled(3) shouldBe 25
  }

  it should "sample at the given times" in new TestSeries {
    val sampled = series.sampleAt(Array(10, 30, 45))

    sampled.length shouldBe 3
    sampled(0) shouldBe 0
    sampled(1) shouldBe 10
    sampled(2) shouldBe 25
  }

  it should "compute correct duration" in new TestSeries with TestEqualPeriod {
    series.duration shouldBe 25
    s1.duration shouldBe 20
    s2.duration shouldBe 20
  }

  it should "compute covariance for series with equivalent periods" in new TestEqualPeriod {
    s1.covariance(s2, s1.duration, 10) shouldBe 4.5 +- 0.001
    s2.covariance(s1, s2.duration, 10) shouldBe 4.5 +- 0.001
    s1.covariance(s2, s1.duration, 5) shouldBe 3.15 +- 0.001
  }

  it should "computer covariance reasonably with default length and period" in new TestEqualPeriod {
    s1.covariance(s2) shouldBe 4.5 +- 0.001
  }

  it should "compute standard deviation" in new TestEqualPeriod {
    s1.standardDeviation(s1.duration, 10) shouldBe 1.5 +- 0.001
    s2.standardDeviation(s2.duration, 10) shouldBe 3.0 +- 0.001
  }

  it should "compute Pearson's correlation for perfectly correlating series" in new TestEqualPeriod {
    s1.pearsonsCorrelationCoefficient(s2) shouldBe 1.0 +- 0.001
  }

  it should "compute covariance and correlation for uncorrelated series" in new TestEqualPeriod with TestNotCorrelated {
    s1.covariance(s3) shouldBe -6.1125 +- 0.001
    s1.pearsonsCorrelationCoefficient(s3) shouldBe -0.5203192 +- 0.001
  }

  it should "normalize the data" in new TestSeries {
    val sampled = series.normalize(17.5, 6.454972).sampleFrom(10, 40, 10)

    sampled.length shouldBe 5
    sampled(0) shouldBe 0
    sampled(1) shouldBe -1.1618950 +- 0.001
    sampled(2) shouldBe -1.1618950 +- 0.001
    sampled(3) shouldBe 0.3872983 +- 0.001
    sampled(4) shouldBe 1.1618950 +- 0.001
  }

  it should "add to the data" in new TestSeries {
    val sampled = series.addTo(3).sampleFrom(10, 40, 10)

    sampled.length shouldBe 5
    sampled(0) shouldBe 0
    sampled(1) shouldBe 13
    sampled(2) shouldBe 13
    sampled(3) shouldBe 23
    sampled(4) shouldBe 28
  }
}
