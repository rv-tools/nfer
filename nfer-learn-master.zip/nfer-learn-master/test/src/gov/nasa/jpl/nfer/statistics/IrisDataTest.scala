package gov.nasa.jpl.nfer.statistics

import gov.nasa.jpl.nfer.UnitSpec

/**
 * Created by seanmk on 1/4/16.
 */
class IrisDataTest extends UnitSpec {
  trait Iris {
    val iris = IrisData.loadDataFrame("iris.data")
  }

  it should "Load the iris data" in new Iris {
    iris.splitByLabel.keys.size shouldBe 3
    iris.data.size shouldBe 150
  }
}
