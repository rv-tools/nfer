package gov.nasa.jpl.nfer.statistics

import gov.nasa.jpl.nfer.util.CSV

import scala.io.Source

/**
 * Created by seanmk on 1/4/16.
 */
object IrisData {
  def loadDataFrame(filename:String):LabeledDataFrame[(Int, String)] = {
    val source = Source.fromURL(getClass.getResource(s"/$filename"))
    val csv = CSV.parseFile(source)

    val dimensions = csv.getKeys.dropRight(1)
    val labelColumn = csv.getKeys.last

    var data = Map.empty[(Int, String), Map[String, Double]]
    var keys = List.empty[(Int, String)]
    var labels = Set.empty[String]
    var index = 0
    for (row <- csv) {
      data += (index, row(labelColumn)) -> (row.toMap - labelColumn).mapValues(value => value.toDouble)
      keys ::= (index, row(labelColumn))
      labels += row(labelColumn)
      index += 1
    }

    val labelMap = labels.zipWithIndex.toMap

    val dataframe = new DataFrame[(Int, String)](dimensions, data, keys)
    dataframe.label { case (row, label) => labelMap.getOrElse(label, -1) }
  }
}
