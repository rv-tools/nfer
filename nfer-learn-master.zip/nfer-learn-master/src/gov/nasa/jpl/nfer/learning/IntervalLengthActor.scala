package gov.nasa.jpl.nfer.learning

import gov.nasa.jpl.nfer.client._
import gov.nasa.jpl.nfer.lang.{Interval, Episode}
import gov.nasa.jpl.nfer.statistics.Summary
import gov.nasa.jpl.nfer.util.Util

import scala.collection.mutable.HashMap


/**
 * Created by seanmk on 11/2/15.
 */
class IntervalLengthActor extends NferActor("intervalLengthActor") {
  val statsPerEvent = new HashMap[String, Summary]()

  override def subscriptions = List(new EpisodeMatcher().kind(Interval.kind))

  override def receiveEpisode(episode:Episode) = episode match {
    case interval:Interval => {
      Util.traceln(5, s"Stats received ${interval.name} interval episode with start ts ${interval.start}, " +
        s"end ts ${interval.end}")

      val stats = statsPerEvent.getOrElseUpdate(interval.name, new Summary)
      val difference = interval.end - interval.start
      if (stats.deviationsAway(difference) < 1 && stats.percentAway(difference) < 1) {
        stats.add(difference)
      } else {
        Util.traceln(0, s"!!!! Interval lies too far from the mean! $difference")
      }

      Util.traceln(0, s"** Interval Duration Stats ${stats.toString}")
    }
    case _ => Util.traceln(0, s"IntervalStatsActor received an unexpected episode!")
  }

}
