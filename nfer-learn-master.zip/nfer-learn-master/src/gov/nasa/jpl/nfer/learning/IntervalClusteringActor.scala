package gov.nasa.jpl.nfer.learning

import java.io.{File, PrintWriter}

import gov.nasa.jpl.nfer.client.{EpisodeMatcher, NferActor}
import gov.nasa.jpl.nfer.lang._
import gov.nasa.jpl.nfer.statistics._
import gov.nasa.jpl.nfer.util.Util

import breeze.linalg.{DenseVector, eig, eigSym, DenseMatrix}


/**
 * Created by seanmk on 11/3/15.
 */

class IntervalClusteringActor extends NferActor("intervalClusteringActor") {
  val intervalName = "Shutdown"

  override def subscriptions = List(new EpisodeMatcher().kind(EndOfStream.kind))

  override def receiveEpisode(episode:Episode) = episode match {
    case eos:EndOfStream => {
      Util.traceln(1, s"$intervalName $actorName received EOS ${eos.name}")

      val dataframe = new DataFrame[Interval]()
      val intervalMatcher = new EpisodeMatcher().kind(Interval.kind).name(intervalName)
      val intervalsMatched = database.query[Interval](intervalMatcher)
      for (interval <- intervalsMatched) {
        val ehaMatcher = new EpisodeMatcher().kind("episode").fieldRange("sclk", interval.start - 540, interval.end)
        val ehasMatched = database.query[Episode](ehaMatcher)
        dataframe.addOrUpdateRow[Episode](interval, ehasMatched, (e:Episode) => s"${e.name}_MAX_END", new MaxFieldValue("end"))
        dataframe.addOrUpdateRow[Interval](interval, List(interval).iterator, (i:Interval) => "DURATION", new DifferenceValue("end", "start"))
      }

      val normalized = dataframe.nonEmpty.normalize
      val dimensions = normalized.getDimensionTable
      val keys = normalized.getKeys

      Util.traceln(0, s"Interval vectors\n${dataframe.toString}")

      val average = new Summary
      for (interval <- keys) {
        average.add(interval.end - interval.start)
      }

      // if the interval is longer than threshold, it's a long interval
      val threshold = average.arithmeticMean + (average.standardDeviation * 3)
      Util.traceln(0, s"Average interval length is $average, threshold is $threshold")

      val labelFunction = (interval:Interval) => if (interval.end - interval.start > threshold) 1 else 0

      val labeledData = normalized.label(labelFunction)
      val splitByLabel = labeledData.splitByLabel
      val longDataframe = splitByLabel.getOrElse(1, new DataFrame[Interval])
      val shortDataframe = splitByLabel.getOrElse(0, new DataFrame[Interval])

      Util.traceln(0, s"Long Data Frame ${longDataframe.getMultivariateSummary.toString}")
      Util.traceln(0, s"Short Data Frame ${shortDataframe.getMultivariateSummary.toString}")

      val mvSeries = normalized.getMultivariateSummary
      Util.traceln(0, mvSeries.toString)

      // get separate groups for long and short intervals
      val long = longDataframe.getMatrix

      // tf-idf calculation
      val idf = normalized.getIndependentDocumentFrequency
      for (vector <- long) {
        Util.traceln(5, s"Long tf vector    : [${vector.mkString(",")}]")
        Util.traceln(5, s"Idf vector        : [${idf.toArray.mkString(",")}]")
        Util.traceln(0, s"Long tf-idf vector: [${idf.getTfIdf(vector).mkString(",")}]")
      }

      // k-NN classification
      val k = 2
      val knn = new KNearestNeighbors[Interval](k, new EuclideanDistance)
      val (training, test) = labeledData.splitRandom(0.60)
      Util.traceln(0, s"Splitting randomly, training is ${training.keys.length}, test is ${test.keys.length}")
      knn.train(training)
      val accuracy = knn.validate(test)
      Util.traceln(0, s"K-Nearest Neighbors, k = $k, accuracy is $accuracy")

      // write a tsv file with all the data
      val writer = new PrintWriter(new File(s"/var/tmp/$intervalName.tsv"))
      writer.write(labeledData.toString)
      writer.close()

      // just try to use PCA
      val pca = new PrincipalComponentAnalysis[Interval]
      pca.train(labeledData)
      val principalled = pca.reduce(labeledData, k * 2)
      Util.traceln(0, s"Principal dimensions:\n${principalled.toString}")

      // k-NN classification
      val knn2 = new KNearestNeighbors[Interval](k, new EuclideanDistance)
      val (training2, test2) = principalled.label(labelFunction).splitRandom(0.60)
      knn2.train(training2)
      val accuracy2 = knn2.validate(test2)
      Util.traceln(0, s"K-Nearest Neighbors, k = $k, accuracy is $accuracy2")

      // just try to use LDA
      val lda = new LinearDiscriminantAnalysis[Interval]
      lda.train(labeledData)
      val discriminated = lda.reduce(labeledData, k - 1)
      Util.traceln(0, s"Discriminated dimensions:\n${discriminated.toString}")

      // k-NN classification
      val knn3 = new KNearestNeighbors[Interval](k, new EuclideanDistance)
      val (training3, test3) = discriminated.label(labelFunction).splitRandom(0.60)
      knn3.train(training3)
      val accuracy3 = knn3.validate(test3)
      Util.traceln(0, s"K-Nearest Neighbors, k = $k, accuracy is $accuracy3")
    }
    case _ => Util.traceln(0, s"$actorName received an unknown episode")
  }
}