package gov.nasa.jpl.nfer.statistics

/**
 * Created by seanmk on 12/4/15.
 */
class LabeledDataFrame[K](labelingFunction:(K) => Int, dataframe:DataFrame[K]) extends DataFrame[K](dataframe) {

  def getLabeledVector(key:K):(Int, Array[Double]) = {
    (labelingFunction(key), getVector(key))
  }

  def getAllLabeledVectors:Array[(Int, Array[Double])] = {
    keys.map((key) => getLabeledVector(key)).toArray
  }

  def splitByLabel:Map[Int, DataFrame[K]] = {
    var split = Map[Int, DataFrame[K]]()
    for (key <- keys) {
      val label = labelingFunction(key)
      val where = split.getOrElse(label, new DataFrame[K](dimensions, Map.empty[K, Map[String, Double]], List.empty[K]))
      where.data += key -> data(key)
      where.keys ::= key
      split += label -> where
    }
    split
  }

  override def normalize:LabeledDataFrame[K] = {
    new LabeledDataFrame[K](labelingFunction, super.normalize)
  }

  override def splitRandom(percent:Double):(LabeledDataFrame[K], LabeledDataFrame[K]) = {
    val split = splitByLabel
    val firstTotal = DataFrame.empty[K]
    val secondTotal = DataFrame.empty[K]

    // try to split equivalent percentages of each label into the randomized set
    for ((label, dataframe) <- split) {
      val (first, second) = dataframe.splitRandom(percent)
      firstTotal ++= first
      secondTotal ++= second
    }

    (new LabeledDataFrame[K](labelingFunction, firstTotal), new LabeledDataFrame[K](labelingFunction, secondTotal))
  }

  override def toString:String = {
    val builder = new StringBuilder
    val dimensionLookup = getDimensionTable
    val split = splitByLabel

    builder ++= "label\tdimension\tmean\tstd\tmin\tmax\n"
    for ((label, dataframe) <- split) {
      val summary = dataframe.getMultivariateSummary
      val mean = summary.arithmeticMean
      val std = summary.standardDeviation
      val min = summary.minimum
      val max = summary.maximum

      for (i <- mean.indices) {
        builder ++= s"${label.toString}\t${dimensionLookup(i)}\t${mean(i)}\t${std(i)}\t${min(i)}\t${max(i)}\n"
      }
    }
    builder.toString()
  }
}
