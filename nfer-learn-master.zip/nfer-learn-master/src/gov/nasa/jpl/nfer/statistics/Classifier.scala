package gov.nasa.jpl.nfer.statistics

import gov.nasa.jpl.nfer.util.Util

/**
 * Created by seanmk on 12/16/15.
 */
trait Classifier[K] {
  def classify(features:Array[Double]):Int

  def validate(test:LabeledDataFrame[K]):Double = {
    val labeled = test.getAllLabeledVectors
    var right = 0.0

    for ((correct, vector) <- labeled) {
      val predicted = classify(vector)
      if (predicted == correct) {
        right += 1
      } else {
        Util.traceln(2, s"Wrong label: predicted $predicted but should have been $correct")
      }
    }
    Util.traceln(0, s"There are ${labeled.length} labeled vectors")

    right / labeled.length.toDouble
  }
}
