package gov.nasa.jpl.nfer.statistics

/**
 * Created by seanmk on 12/14/15.
 */
trait VectorDistance {
  def distance(first:Array[Double], second:Array[Double]):Double
}

class ChebyshevDistance extends VectorDistance {
  override def distance(first:Array[Double], second:Array[Double]):Double = {
    require(first.length == second.length)
    var max = 0.0
    for (i <- first.indices) {
      val difference = math.abs(first(i) - second(i))
      if (difference > max) max = difference
    }
    max
  }
}

class EuclideanDistance extends VectorDistance {
  override def distance(first:Array[Double], second:Array[Double]):Double = {
    require(first.length == second.length)
    var sum = 0.0
    for (i <- first.indices) {
      sum = math.pow(first(i) - second(i), 2.0)
    }
    math.sqrt(sum)
  }
}