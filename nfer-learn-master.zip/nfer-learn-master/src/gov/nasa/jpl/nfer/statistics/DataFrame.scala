package gov.nasa.jpl.nfer.statistics

import gov.nasa.jpl.nfer.lang.Episode
import gov.nasa.jpl.nfer.util.Util

import scala.collection.mutable

/**
 * Created by seanmk on 12/2/15.
 */
class DataFrame[K] {
  // we need to preserve insertion order, so keep dimensions in a list
  var dimensions = List.empty[String]
  // but we need to quickly test for uniqueness, so keep dimensions in a set too
  var dimensionSet = Set.empty[String]
  // we need quick lookup for data
  var data = Map.empty[K, Map[String, Double]]
  // but we need to preserve key order
  var keys = List.empty[K]

  // cached values
  private var summary:Option[MultivariateSummary] = None
  private var idf:Option[IndependentDocumentFrequency] = None

  def this(newDimensions:TraversableOnce[String], newData:Map[K, Map[String, Double]], newKeys:List[K]) = {
    this()
    dimensions = newDimensions.toList
    dimensionSet = newDimensions.toSet
    data = newData
    keys = newKeys
  }


  def this(newDimensions:TraversableOnce[String], newMatrix:Array[Array[Double]], newKeys:List[K]) = {
    this()
    dimensions = newDimensions.toList
    dimensionSet = newDimensions.toSet
    keys = newKeys

    data = keys.zipWithIndex.foldLeft(Map[K, Map[String, Double]]()) {
      case (accum, (key, i)) => accum + (key -> dimensions.zipWithIndex.map {
        case (dimension, j) => (dimension, newMatrix(i)(j))
      }.toMap)
    }
  }


  def this(dataframe:DataFrame[K]) = {
    this()
    dimensions = dataframe.dimensions
    dimensionSet = dataframe.dimensionSet
    data = dataframe.data
    keys = dataframe.keys
  }

  def ++=(concat:DataFrame[K]) = {
    for (dimension <- concat.dimensions.reverse) {
      if (!dimensionSet.contains(dimension)) {
        dimensions ::= dimension
        dimensionSet += dimension
      }
    }
    // although we try to preserve the order of dimensions, there is no point trying to preserve the order of the data
    Util.traceln(5, s"concat keySet is length ${concat.data.keySet.size}, data keySet is length ${data.keySet.size}")
    keys ++= concat.data.keySet.diff(data.keySet)
    data ++= concat.data
  }

  def label(labelingFunction:(K) => Int):LabeledDataFrame[K] = {
    new LabeledDataFrame(labelingFunction, this)
  }

  def addOrUpdateRow[D <: Episode](key:K, items:TraversableOnce[D], dimensionName:(D) => String, dimensionValue:DimensionValue) = {
    val eventData = data.getOrElse(key, Map.empty[String, Double])
    var map = Map[String, DimensionValue]()
    // Episode is sorted on start, then end timestamps
    // Sort so timeseries data is correct
    val sorted = items.toList.sorted

    for (item <- sorted) {
      val name = dimensionName(item)
      if (!dimensionSet.contains(name)) {
        // this is an O(n) operation, but it shouldn't happen much
        // we want the insertion order to be preserved, not reversed
        dimensions :+= name
        dimensionSet += name
      }
      val value = map.getOrElse(name, dimensionValue.spawn)

      value.add(item)
      map = map + (name -> value)
    }
    // add the key if it isn't present
    if (eventData.isEmpty) {
      // this is a much faster O(1) operation than the dimension insertion
      keys ::= key
    }
    // add the row to data
    data += key -> (eventData ++ map.mapValues { case (dm) => dm.value })

    // clear the cached values
    summary = None
    idf = None

    map
  }

  def getDimensionTable:Array[String] = {
    dimensions.toArray
  }

  def normalize:DataFrame[K] = {
    val dimensionTable = getDimensionTable
    // getMultivariateSummary caches its result, so it is not expensive to call it multiple times
    val counts = (dimensionTable zip getMultivariateSummary.count).toMap
    val means = (dimensionTable zip getMultivariateSummary.arithmeticMean).toMap
    val stds = (dimensionTable zip getMultivariateSummary.standardDeviation).toMap

    val newData = data.mapValues[Map[String, Double]]((map) => map.filter {
      // filter out data for which there is only one value
      case (dimension, orig) => counts(dimension) > 1
    }.map {
      // normalize to mean = 0.0 std = 1.0
      case (dimension, orig) =>
        (dimension, (orig - means(dimension)) / stds(dimension))
    })

    // we're not removing any rows or dimensions, so just pass those lists
    new DataFrame[K](dimensions, newData, keys)
  }

  def nonNegative:DataFrame[K] = {
    // get the minimum value
    val allMinimums = new Summary()
    getMultivariateSummary.minimum.foreach(eachMin => allMinimums.add(eachMin))
    // amount to add to make everything positive
    val toAdd = 0 - allMinimums.minimum

    val newData = data.mapValues[Map[String, Double]]((map) => map.map {
      case (dimension, orig) =>
        (dimension, orig + toAdd)
    })

    // we're not removing any rows or dimensions, so just pass those lists
    new DataFrame[K](dimensions, newData, keys)
  }

  def nonEmpty:DataFrame[K] = {
    // if a key exists in the keys list it should be safe to retrieve the map entry
    new DataFrame[K](dimensions, data.filter { case (key, map) => map.nonEmpty }, keys.filter(key => data(key).nonEmpty))
  }

  /**
   * Get a new DataFrame with only the first n dimensions
   * @param n the number of dimensions to include
   * @return a DataFrame with only the first n dimensions
   */
  def take(n:Int):DataFrame[K] = {
    new DataFrame[K](dimensions.take(n), data, keys)
  }

  def splitRandom(percent:Double):(DataFrame[K], DataFrame[K]) = {
    require(percent < 1.0 && percent > 0.0)
    var firstMap = Map.empty[K, Map[String, Double]]
    var firstKeys = List.empty[K]
    var secondMap = Map.empty[K, Map[String, Double]]
    var secondKeys = List.empty[K]
    // iterate backwards over the rows
    for (i <- (keys.length - 1) to 0 by -1) {
      val key = keys(i)
      if (math.random < percent) {
        firstMap += key -> data(key)
        firstKeys ::= key
      } else {
        secondMap += key -> data(key)
        secondKeys ::= key
      }
    }
    (new DataFrame[K](dimensions, firstMap, firstKeys), new DataFrame[K](dimensions, secondMap, firstKeys))
  }

  def getRowValues(key:K):Map[String, Double] = {
    data.getOrElse(key, Map.empty[String, Double])
  }

  def getVector(key:K):Array[Double] = {
    dimensions.map((dimension) => getRowValues(key).getOrElse(dimension, 0.0)).toArray
  }

  def getMatrix:Array[Array[Double]] = {
    val result = new Array[Array[Double]](keys.length)
    keys.zipWithIndex.foreach { case (key, index) => result(index) = getVector(key) }
    result
  }

  def getKeys:TraversableOnce[K] = {
    keys
  }

  def covarianceBetween(dimensionOne:Int, dimensionTwo:Int):Double = {
    val meanVector = getMultivariateSummary.arithmeticMean
    val vectors = getMatrix

    var sum = 0.0
    for (vector <- vectors) {
      sum += (vector(dimensionOne) - meanVector(dimensionOne)) * (vector(dimensionTwo) - meanVector(dimensionTwo))
    }
    sum / (vectors.length - 1)
  }

  def pearsonsCorrelationBetween(dimensionOne:Int, dimensionTwo:Int):Double = {
    val covariance = covarianceBetween(dimensionOne, dimensionTwo)
    val std = getMultivariateSummary.standardDeviation
    covariance / (std(dimensionOne) * std(dimensionTwo))
  }

  /**
   * Computes the covariance matrix for the DataFrame.
   * This runs in O(nmm) time where n is the number of rows and m is the number of dimensions
   * @return the covariance matrix
   */
  def getCovarianceMatrix:Array[Array[Double]] = {
    // initialize the matrix
    val matrix = new Array[Array[Double]](dimensions.size)
    for (i <- matrix.indices) {
      matrix(i) = new Array[Double](dimensions.size)
    }

    val meanVector = getMultivariateSummary.arithmeticMean
    val vectors = getMatrix

    for (i <- dimensions.indices) {
      for (j <- i until dimensions.size) {
        var sum = 0.0
        for (vector <- vectors) {
          sum += (vector(i) - meanVector(i)) * (vector(j) - meanVector(j))
        }
        matrix(i)(j) = sum / (vectors.length - 1)
        // symetry
        matrix(j)(i) = matrix(i)(j)
      }
    }
    matrix
  }

  def getMultivariateSummary:MultivariateSummary = {
    summary match {
      case Some(existingSeries) => existingSeries
      case None => {
        val newSeries = new MultivariateSummary(dimensions.size)
        // order is unimportant
        data.values.foreach(map => newSeries.add(dimensions, map))
        // cache it
        summary = Some(newSeries)
        newSeries
      }
    }
  }

  def getIndependentDocumentFrequency:IndependentDocumentFrequency = {
    idf match {
      case Some(existingIdf) => existingIdf
      case None => {
        val newIdf = new IndependentDocumentFrequency(dimensions.size)
        // order is unimportant
        data.values.foreach(map => newIdf.add(dimensions, map))
        // cache it
        idf = Some(newIdf)
        newIdf
      }
    }
  }

  override def toString:String = {
    val builder = new StringBuilder
    val dimensionLookup = getDimensionTable
    val summary = getMultivariateSummary
    val mean = summary.arithmeticMean
    val std = summary.standardDeviation
    val min = summary.minimum
    val max = summary.maximum

    builder ++= "dimension\tmean\tstd\tmin\tmax\n"
    for (i <- mean.indices) {
      builder ++= s"${dimensionLookup(i)}\t${mean(i)}\t${std(i)}\t${min(i)}\t${max(i)}\n"
    }
    builder.toString()
  }
}

object DataFrame {
  def empty[K]:DataFrame[K] = {
    val dimensions = List.empty[String]
    val data = Map.empty[K, Map[String, Double]]
    val keys = List.empty[K]
    new DataFrame[K](dimensions, data, keys)
  }
}