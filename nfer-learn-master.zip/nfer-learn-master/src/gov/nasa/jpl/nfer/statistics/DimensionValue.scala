package gov.nasa.jpl.nfer.statistics

import gov.nasa.jpl.nfer.lang.Episode

/**
 * Created by seanmk on 12/3/15.
 */
trait DimensionValue {
  def add(episode:Episode)
  def value:Double
  def spawn:DimensionValue
}

class CountValue() extends DimensionValue {
  var count:Double = 0.0
  override def add(episode:Episode) = { count += 1 }
  override def value = count
  override def spawn = new CountValue
}

class DifferenceValue(field:String, toSubtract:String) extends DimensionValue {
  var difference:Double = 0.0
  override def add(episode:Episode) = { difference = episode.get(field).toDouble - episode.get(toSubtract).toDouble }
  override def value = difference
  override def spawn = new DifferenceValue(field, toSubtract)
}

class MostRecentFieldValue(field:String) extends DimensionValue {
  var start:Double = Double.MinValue
  var last:Double = 0.0
  override def add(episode:Episode) = {
    // for DataFrame this should always be true since the episodes are sorted by start, but let's be safe
    if (episode.start > start) {
      last = episode.get(field).toDouble
      start = episode.start
    }
  }
  override def value = last
  override def spawn = new MostRecentFieldValue(field)
}

class TimeSinceLastEventValue(startEvent:Episode) extends DimensionValue {
  var current = startEvent
  override def add(episode:Episode) = current = episode
  override def value = current.start - startEvent.start
  override def spawn = new TimeSinceLastEventValue(current)
}

abstract class FieldValue(field:String) extends DimensionValue {
  val series = new Summary
  override def add(episode:Episode) = { series.add(episode.get(field).toDouble) }
}

class MaxFieldValue(field:String) extends FieldValue(field) {
  override def value = series.maximum
  override def spawn = new MaxFieldValue(field)
}

class MinFieldValue(field:String) extends FieldValue(field) {
  override def value = series.minimum
  override def spawn = new MinFieldValue(field)
}