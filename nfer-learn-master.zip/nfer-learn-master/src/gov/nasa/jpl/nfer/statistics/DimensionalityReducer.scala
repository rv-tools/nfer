package gov.nasa.jpl.nfer.statistics

/**
 * Created by seanmk on 1/6/16.
 */
trait DimensionalityReducer[K] {

  def reduce(start:DataFrame[K], keep:Int):DataFrame[K]
}
