package gov.nasa.jpl.nfer.statistics

import scala.collection.mutable

/**
 * Created by seanmk on 12/9/15.
 */

case class Sample(timestamp:Double, value:Double)

class TimeSeries {
  private val order = Ordering[Double].on[Sample](sample => sample.timestamp)
  private val points = mutable.SortedSet[Sample]()(order)

  def this(newPoints:mutable.SortedSet[Sample]) = {
    this()
    points ++= newPoints
  }

  def add(timestamp:Double, value:Double) = {
    points.add(Sample(timestamp, value))
  }

  def sampleFrom(start:Double, length:Double, period:Double):Array[Double] = {
    val series = new Array[Double]((length / period).toInt + 1)
    var time = start
    var next = Sample(start, 0.0)
    var last = next
    val iterator = points.iteratorFrom(next)

    while (time <= (start + length)) {
      while (next.timestamp <= time) {
        last = next
        if (iterator.hasNext) {
          next = iterator.next()
        } else {
          // this just breaks out of the while loop and ensures it isn't run again
          next = Sample(start + length + 1, 0.0)
        }
      }
      series(((time - start) / period).toInt) = last.value

      time += period
    }
    series
  }

  def sampleAt(sampleTimes:Array[Double]):Array[Double] = {
    require(sampleTimes.length > 0)
    val series = new Array[Double](sampleTimes.length)
    var next = Sample(sampleTimes.head, 0.0)
    var last = next
    val iterator = points.iteratorFrom(next)
    var count = 0

    for (time <- sampleTimes) {
      while (next.timestamp <= time) {
        last = next
        if (iterator.hasNext) {
          next = iterator.next()
        } else {
          // this just breaks out of the while loop and ensures it isn't run again
          next = Sample(sampleTimes.last + 1, 0.0)
        }
      }
      series(count) = last.value

      count += 1
    }
    series
  }

  def duration:Double = points.last.timestamp - points.head.timestamp

  def start:Double = points.head.timestamp

  def covariance(compare:TimeSeries):Double = {
    val length = math.max(duration, compare.duration)
    // this is somewhat arbitrary: we just sample at approximately the average rate
    val period = length / (math.max(points.size, compare.points.size) - 1)

    covariance(compare, length, period)
  }

  def covariance(compare:TimeSeries, length:Double, period:Double):Double = {
    var powerSum = 0.0

    val one = sampleFrom(start, length, period)
    val two = compare.sampleFrom(compare.start, length, period)

    val average = one.sum / one.length
    val otherAverage = two.sum / two.length

    var sum = 0.0
    for (i <- one.indices) {
      sum += (one(i) - average) * (two(i) - otherAverage)
    }

    sum / (one.length - 1)
  }

  def standardDeviation(length:Double, period:Double):Double = {
    math.sqrt(covariance(this, length, period))
  }

  def pearsonsCorrelationCoefficient(compare:TimeSeries):Double = {
    val length = math.max(duration, compare.duration)
    // this is somewhat arbitrary: we just sample at approximately the average rate
    val period = length / (math.max(points.size, compare.points.size) - 1)

    covariance(compare, length, period) / (standardDeviation(length, period) *
      compare.standardDeviation(length, period))
  }

  def normalize(mean:Double, std:Double):TimeSeries = {
    val newPoints = points.foldLeft[mutable.SortedSet[Sample]](mutable.SortedSet[Sample]()(order))(
      (accum, sample) => {
        accum.add(Sample(sample.timestamp, (sample.value - mean) / std))
        accum
      })
    new TimeSeries(newPoints)
  }

  def addTo(toAdd:Double):TimeSeries = {
    val newPoints = points.foldLeft[mutable.SortedSet[Sample]](mutable.SortedSet[Sample]()(order))(
      (accum, sample) => {
        accum.add(Sample(sample.timestamp, sample.value + toAdd))
        accum
      })
    new TimeSeries(newPoints)
  }

  override def toString:String = {
    s"${points.map(sample => sample.timestamp).mkString("\t")}\n${points.map(sample => sample.value).mkString("\t")}"
  }
}
