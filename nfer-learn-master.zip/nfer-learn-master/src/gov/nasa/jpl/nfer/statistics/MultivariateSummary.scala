package gov.nasa.jpl.nfer.statistics

/**
 * Created by seanmk on 11/23/15.
 */
class MultivariateSummary(size:Int) {
  val each = new Array[Summary](size)
  var rows = 0
  // actually instantiate the items
  for (i <- each.indices) {
    each(i) = new Summary
  }

  def add(vector:Array[Double]) = {
    require(vector.length == size)

    for (i <- vector.indices) {
      each(i).add(vector(i))
    }
    rows += 1
  }

  def add(lookup:TraversableOnce[String], map:Map[String, Double]) = {
    require(lookup.size == size)

    var i = 0
    for (key <- lookup) {
      val get = map.get(key)
      get match {
        case Some(word) => each(i).add(word)
        case None => // do nothing
      }
      i += 1
    }
    rows += 1
  }

  def remove(vector:Array[Double]) = {
    require(vector.length == size)

    for (i <- vector.indices) {
      each(i).remove(vector(i))
    }
  }

  override def toString:String = {
    s"Multivariate Summary ($rows rows):\n" +
      s"Arithmetic Mean     [${arithmeticMean.mkString(",")}]\n" +
      s"Minimum             [${minimum.mkString(",")}]\n" +
      s"Maximum             [${maximum.mkString(",")}]\n" +
      s"Standard Deviation  [${standardDeviation.mkString(",")}]"
  }

  def count:Array[Int] = {
    each.map(series => series.count)
  }

  def arithmeticMean:Array[Double] = {
    each.map(series => series.arithmeticMean)
  }

  def standardDeviation:Array[Double] = {
    each.map(series => series.standardDeviation)
  }

  def minimum:Array[Double] = {
    each.map(series => series.minimum)
  }

  def maximum:Array[Double] = {
    each.map(series => series.maximum)
  }
}