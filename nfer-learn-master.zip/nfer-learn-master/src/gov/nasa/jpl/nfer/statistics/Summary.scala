package gov.nasa.jpl.nfer.statistics

import scala.collection.mutable.ListBuffer

/**
 * Created by seanmk on 11/2/15.
 */
class Summary {
  var list = new ListBuffer[Double]
  var count:Int = 0
  var sum:Double = 0.0
  private var mean:Double = 0.0
  private var powerSumAverage:Double = 0.0
  private var min:Double = Double.MaxValue
  private var max:Double = Double.MinValue

  def deviationsAway(item:Double):Double = {
    val distance = math.abs(item - mean)
    if (count > 1) distance / standardDeviation
    else 0
  }

  def percentAway(item:Double):Double = {
    val distance = math.abs(item - mean)
    if (mean > 0) distance / mean
    else 0
  }

  def add(item:Double) = {
    // add to the list
    list += item
    // update the count first
    count += 1
    // update the rolling average
    mean += (item - mean) / count
    // update the power sum average
    powerSumAverage += (item * item - powerSumAverage) / count
    // update the sum
    sum += item
    // update min and max if necessary
    if (item > max) max = item
    if (item < min) min = item
  }

  // TODO is there really a requirement to remove items?  If not we can ditch the list.
  def remove(item:Double) = {
    // removing the item from the list is a linear time operation!
    list -= item
    // Roll back the average to not include this item
    mean =  ((count * mean) - item) / (count - 1)
    // Roll back the power sum average to not include this item
    powerSumAverage = ((powerSumAverage * count) - (item * item)) / (count - 1)
    // Roll back the count
    count -= 1
    // Rull back the sum
    sum -= item
    // handle min and max together, since we can find them both with one loop
    if (min == item || max == item) {
      min = Double.MaxValue
      max = Double.MinValue
      for (value <- list) {
        if (value > max) max = value
        if (value < min) min = value
      }
    }
  }

  def arithmeticMean:Double = mean
  def standardDeviation:Double =
    if (count > 1)
      math.sqrt(((powerSumAverage * count) - (count * mean * mean)) / (count - 1))
    else
      0

  def minimum:Double = if (count > 0) min else 0.0
  def maximum:Double = if (count > 0) max else 0.0

  // this is unfortunate... maybe switch to a fast approximation
  def median:Double = {
    val sorted = list.sorted
    val center = sorted.length / 2
    if (sorted.length % 2 == 0) {
      sorted(center)
    } else {
      (sorted(center + 1) - sorted(center)) / 2
    }
  }

  override def toString:String = s"Count: $count, Arith Mean: $mean, Std Dev: $standardDeviation"
}
