package gov.nasa.jpl.nfer.statistics

/**
 * Created by seanmk on 12/17/15.
 */
trait UnsupervisedLearner[K] {
  def train(sample:DataFrame[K]):Unit
}
