package gov.nasa.jpl.nfer.statistics

import breeze.linalg._
import breeze.linalg.eig.Eig
import gov.nasa.jpl.nfer.util.Util

/**
 * Created by seanmk on 1/6/16.
 */
trait EigenTransformation[K] extends DimensionalityReducer[K] {
  var w:DenseMatrix[Double] = new DenseMatrix[Double](0, 0)

  protected def buildWMatrix(eigen:Eig[DenseVector[Double], DenseMatrix[Double]]):Unit = {
    // get the eigenvalues and eigenvectors
    val eigenValues = eigen.eigenvalues
    val eigenVectors = eigen.eigenvectors

    // to get a vector, do "eigenVectors(::, i)"
    var eigenList = new Array[(Double, DenseVector[Double])](eigenValues.length)
    // populate with pairs of eigenvalues and eigenvectors
    for (i <- eigenList.indices) {
      eigenList(i) = (eigenValues(i), eigenVectors(::, i))
    }
    // sort by eigenvalue
    eigenList = eigenList.sortWith { case ((v0, _), (v1, _)) => v0 > v1 }

    // build a W matrix with all of the eigenvectors
    for (i <- eigenList.indices) {
      val e = eigenList(i)._2.toDenseMatrix.t
      Util.traceln(2, s"PC$i dimension eigenvalue ${eigenList(i)._1}")

      // don't try to include the dummy 0,0 matrix in the result
      if (i == 0) {
        w = e
      } else {
        w = DenseMatrix.horzcat(w, e)
      }
    }
  }

  def reduce(start:DataFrame[K], keep:Int):DataFrame[K] = {
    // the new dimensions are not actually the same as the old ones
    val newOrder = List.tabulate[String](w.cols)(d => s"PC$d")
    val startMatrix = start.getMatrix
    val length = newOrder.length

    // create a breeze matrix so we can do easier linear algebra
    val breezeStart:DenseMatrix[Double] = new DenseMatrix(newOrder.length, startMatrix.length, startMatrix.flatten)

    // dot product
    Util.traceln(5, s"W rows/cols: ${w.rows}/${w.cols}, start matrix rows/cols: ${breezeStart.rows}/${breezeStart.cols}")
    val transformedMatrix:DenseMatrix[Double] = breezeStart.t * w
    // extract the underlying values
    val resultMatrix = new Array[Array[Double]](startMatrix.length)
    for (r <- resultMatrix.indices) {
      resultMatrix(r) = transformedMatrix.t(::, r).toArray
    }

    new DataFrame[K](newOrder.take(keep), resultMatrix, start.keys)
  }
}
