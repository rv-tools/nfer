package gov.nasa.jpl.nfer.statistics

import breeze.linalg._
import gov.nasa.jpl.nfer.util.Util

/**
 * Created by seanmk on 12/17/15.
 */
class PrincipalComponentAnalysis[K] extends EigenTransformation[K] with UnsupervisedLearner[K] {

  def train(sample:DataFrame[K]):Unit = {
    // try to perform PCA...
    val covariance = sample.getCovarianceMatrix
    // convert to a Breeze data structure (covariance matrix is symetric) and compute the eigenvectors
    val eigen = eig(new DenseMatrix(covariance.length, covariance.length, covariance.flatten))

    buildWMatrix(eigen)
  }

}
