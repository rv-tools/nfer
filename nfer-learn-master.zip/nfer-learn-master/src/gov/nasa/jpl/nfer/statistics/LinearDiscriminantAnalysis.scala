package gov.nasa.jpl.nfer.statistics

import breeze.linalg._
import gov.nasa.jpl.nfer.util.Util

/**
 * Created by seanmk on 1/4/16.
 */
class LinearDiscriminantAnalysis[K] extends EigenTransformation[K] with SupervisedLearner[K] {

  override def train(sample:LabeledDataFrame[K]):Unit = {
    // get the separated data frames for each class
    val byLabel = sample.splitByLabel.values
    val dimensions = sample.getDimensionTable

    // get the covariance matrix for each class
    val covarianceMatrices = new Array[DenseMatrix[Double]](byLabel.size)
    byLabel.zipWithIndex.foreach {
      case (dataframe, index) =>
        covarianceMatrices(index) = new DenseMatrix(dimensions.length, dimensions.length, dataframe.getCovarianceMatrix.flatten)
    }

    // compute the within-class scatter matrix from the covariance matrices
    var Sw = new DenseMatrix[Double](dimensions.length, dimensions.length)
    byLabel.zipWithIndex.foreach {
      case (dataframe, index) => Sw += (covarianceMatrices(index) * (dataframe.data.size - 1).toDouble)
    }

    // get the overall mean vector
    val overallMean = new DenseVector(sample.getMultivariateSummary.arithmeticMean)

    // compute the between-class scatter matrix using the mean vectors
    var Sb = new DenseMatrix[Double](dimensions.length, dimensions.length)
    byLabel.foreach(dataframe => {
      val mean = new DenseVector(dataframe.getMultivariateSummary.arithmeticMean)
      val residual = mean - overallMean
      Sb += (residual * residual.t) * dataframe.data.size.toDouble
    })
    // compute the eigenvectors of the inverse product of the two scatter matrices
    val eigen = eig(inv(Sw) * Sb)

    buildWMatrix(eigen)
  }

}
