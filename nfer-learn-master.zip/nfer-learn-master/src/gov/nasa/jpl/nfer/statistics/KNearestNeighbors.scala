package gov.nasa.jpl.nfer.statistics

/**
 * Created by seanmk on 12/15/15.
 */
class KNearestNeighbors[K](k:Int, compare:VectorDistance) extends SupervisedLearner[K] with Classifier[K] {
  var vectors = Array[(Int, Array[Double])]()

  def train(sample:LabeledDataFrame[K]):Unit = {
    vectors = sample.getAllLabeledVectors
  }

  /**
   * This is a naive implementation of KNN, but it should work fine
   * @param features the feature vector to classify
   * @return the predicted label
   */
  def classify(features:Array[Double]):Int = {
    val nearest = Array.fill[(Int, Double)](k)((0, Double.MaxValue))

    for ((label, vector) <- vectors) {
      val distance = compare.distance(features, vector)
      var set = false
      for (i <- nearest.indices) {
        val (l, d) = nearest(i)
        if (!set && distance < d) {
          nearest(i) = (label, distance)
        }
      }
    }

    var counts = Map.empty[Int, Int]

    for ((label, distance) <- nearest) {
      if (distance < Double.MaxValue) {
        val count = counts.getOrElse(label, 0)
        counts += label -> count
      }
    }

    var max = 0
    var predicted = 0
    for ((label, count) <- counts) {
      if (count > max) {
        predicted = label
      }
    }
    predicted
  }
}
