package gov.nasa.jpl.nfer.statistics

import scala.collection.mutable.ArrayBuffer

/**
 * Created by seanmk on 11/17/15.
 */
class IndependentDocumentFrequency(size:Int) {
  private var documentCount = 0
  val wordCounts = new Array[Int](size)

  /**
   * Add a vector of words where positive values indicate word presence.
   * @param values a vector of words where positive values indicate word presence
   */
  def add(values:Array[Double]) = {
    require(values.length == wordCounts.length)

    var i = 0
    for (word <- values) {
      if (word > 0.0) {
        wordCounts(i) += 1
      }
      i += 1
    }

    documentCount += 1
  }

  /**
   * Add words from a dimension lookup and map
   * @param lookup a list of strings mapping dimension numbers to keys
   * @param map a map of keys to values, where presence in the map indicates word presence
   */
  def add(lookup:TraversableOnce[String], map:Map[String, Double]) = {
    require(lookup.size == wordCounts.length)

    var i = 0
    for (key <- lookup) {
      val get = map.get(key)
      get match {
        case Some(word) => wordCounts(i) += 1
        case None => // do nothing
      }
      i += 1
    }
    documentCount += 1
  }

  def toArray:Array[Double] = {
    val result = new Array[Double](wordCounts.length)
    for (i <- wordCounts.indices) {
      result(i) = if (wordCounts(i) > 0) math.log(documentCount.toDouble / wordCounts(i).toDouble) else 0
    }
    result
  }

  def getTfIdf(termFrequency:Array[Double]):Array[Double] = {
    require(termFrequency.length == wordCounts.length)

    for ((tf, idf) <- termFrequency zip this.toArray) yield tf * idf
  }
}
