package gov.nasa.jpl.nfer.statistics

/**
 * Created by seanmk on 12/16/15.
 */
trait SupervisedLearner[K] {
  def train(sample:LabeledDataFrame[K]):Unit
}
