package gov.nasa.jpl.nfer.client

/**
 * Created by seanmk on 12/3/15.
 */
class TestPubSubClient extends PubSubClient {
  var lastMessage = ""
  var lastMatcher = new EpisodeMatcher

  def disconnect() = {
    // do nothing
  }
  def publish(matcher:EpisodeMatcher, message:String, qos:QOS.Value) = {
    lastMessage = message
    lastMatcher = matcher
  }
  def subscribe(matcher:EpisodeMatcher, qos:QOS.Value) = {
    lastMatcher = matcher
  }
  def unsubscribe(matcher:EpisodeMatcher) = {
    lastMatcher = matcher
  }
}
