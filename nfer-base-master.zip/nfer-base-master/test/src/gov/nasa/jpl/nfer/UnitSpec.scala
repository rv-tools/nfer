package gov.nasa.jpl.nfer

import org.scalatest._

abstract class UnitSpec extends FlatSpec with Matchers
