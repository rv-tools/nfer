package gov.nasa.jpl.nfer.lang

/**
 * Created by seanmk on 11/4/15.
 */
case class TestEvent(name:String, start:Double) extends Episode {
  val end = start
  val kind = "test"
  val map = Map.empty[String,String]
}
