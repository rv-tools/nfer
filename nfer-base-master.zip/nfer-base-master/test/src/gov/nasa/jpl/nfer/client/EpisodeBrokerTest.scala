package gov.nasa.jpl.nfer.client

import gov.nasa.jpl.nfer.UnitSpec
import gov.nasa.jpl.nfer.lang.{EndOfStream, Episode, Interval}

/**
 * Created by seanmk on 12/3/15.
 */
class EpisodeBrokerTest extends UnitSpec {
  trait Broker {
    val pubsub = new TestPubSubClient
    val broker = new EpisodeBroker(pubsub)

    val eos = new EndOfStream("TEST_EOS")
    var lastEvent:Episode = eos
    broker.callback = (event:Episode) => {
      lastEvent = event
    }

    val interval = Interval("TEST_INTERVAL", 2.0, 5.0)
    val intervalString =
      s"""{"kind":"Interval","name":"${interval.name}","start":${interval.start},"end":${interval.end},"map":{}}"""

    val goodMatcher = EpisodeMatcher(interval).fieldPrefix("name","TEST")
    val badMatcher = EpisodeMatcher(interval).fieldRange("start", 3.0, 6.0)
  }

  it should "serialize properly when publishing" in new Broker {
    broker.publish(interval)
    pubsub.lastMessage shouldBe intervalString
  }

  it should "pass the right EpisodeMatcher when publishing" in new Broker {
    broker.publish(interval)
    // this is a cheaty way to do equality...
    pubsub.lastMatcher.toString shouldBe EpisodeMatcher(interval).toString
  }

  it should "deserialize and pass the episode when a matcher matches" in new Broker {
    pubsub.callback(List(goodMatcher), intervalString)
    lastEvent shouldBe interval
  }

  it should "not pass the episode through when no matchers match" in new Broker {
    pubsub.callback(List(badMatcher), intervalString)
    lastEvent shouldBe eos
  }
}
