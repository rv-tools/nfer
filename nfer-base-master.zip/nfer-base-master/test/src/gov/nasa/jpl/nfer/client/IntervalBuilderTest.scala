package gov.nasa.jpl.nfer.client

import gov.nasa.jpl.nfer.UnitSpec
import gov.nasa.jpl.nfer.lang.TestEvent
import gov.nasa.jpl.nfer.persistence.IntervalBuilder

/**
 * Created by seanmk on 11/4/15.
 */
class IntervalBuilderTest extends UnitSpec {
  trait Builder {
    val builder = new IntervalBuilder("TEST_INTERVAL", "TEST_START", "TEST_END", 100)
    val startEvent = TestEvent(builder.startName, 0)
    val laterStartEvent = TestEvent(builder.startName, 20)
    val endEvent = TestEvent(builder.endName, 50)
    val laterEndEvent = TestEvent(builder.endName, 70)
    val muchLaterEndEvent = TestEvent(builder.endName, builder.maxDuration * 10)
    val secondIntervalStart = TestEvent(builder.startName, 60)
    val eventName = "ANOTHER_TEST_EVENT_TYPE"
    val middleFeature = TestEvent(eventName, 35)
  }

  it should "capture a start episode and return None if no end episode matches" in new Builder {
    builder.add(startEvent) shouldBe empty
  }
  it should "capture an end episode and return None if no start episode matches" in new Builder {
    builder.add(endEvent) shouldBe empty
  }
  it should "capture a start episode and return an interval if an end episode matches" in new Builder {
    builder.add(endEvent)
    builder.add(startEvent) should not be empty
  }
  it should "capture an end episode and return an interval if a start episode matches" in new Builder {
    builder.add(startEvent)
    builder.add(endEvent) should not be empty
  }
  it should "return an interval with the nearest end episode" in new Builder {
    builder.add(endEvent)
    builder.add(laterEndEvent)
    val interval = builder.add(startEvent)
    interval should not be empty
    for (int <- interval) int.end shouldBe endEvent.start
  }
  it should "return an interval with the nearest start episode" in new Builder {
    builder.add(startEvent)
    builder.add(laterStartEvent)
    val interval = builder.add(endEvent)
    interval should not be empty
    for (int <- interval) int.start shouldBe laterStartEvent.start
  }
  it should "return None if the duration is too long" in new Builder {
    builder.add(startEvent)
    builder.add(muchLaterEndEvent) shouldBe empty
    builder.add(laterStartEvent) shouldBe empty
  }
  it should "return None if no intervals match an episode" in new Builder {
    builder.add(middleFeature) shouldBe empty
  }
}
