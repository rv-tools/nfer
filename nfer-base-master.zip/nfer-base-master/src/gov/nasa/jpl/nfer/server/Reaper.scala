package gov.nasa.jpl.nfer.server

import akka.actor.{PoisonPill, Actor, ActorRef, Terminated}
import gov.nasa.jpl.nfer.server.Reaper.{Watch, Shutdown}
import scala.collection.mutable.ArrayBuffer

/**
 * Created by seanmk on 11/10/15.
 */
class Reaper extends Actor {
  // Keep track of what we're watching
  val watched = ArrayBuffer.empty[ActorRef]

  // Watch and check for termination
  def receive = {
    case Shutdown =>
      watched.foreach(_ ! PoisonPill)
    case Watch(ref) =>
      context.watch(ref)
      watched += ref
    case Terminated(ref) =>
      watched -= ref
      if (watched.isEmpty) context.system.shutdown()
  }
}

object Reaper {
  // Used by others to register an Actor for watching
  case class Watch(ref: ActorRef)
  // Used to tell the reaper to shut everything down
  case class Shutdown()
}