package gov.nasa.jpl.nfer.server

import java.io.File
import java.net.URLClassLoader

import akka.actor.{Props, ActorSystem}
import akka.pattern.ask
import akka.util.Timeout
import com.typesafe.config.{ConfigException, ConfigFactory, Config}
import gov.nasa.jpl.nfer.client.Ping
import gov.nasa.jpl.nfer.server.Reaper.{Watch, Shutdown}
import gov.nasa.jpl.nfer.util.Util

import scala.collection.JavaConversions._
import scala.concurrent.Await
import scala.concurrent.duration._

class NferApp() extends ApplicationLifecycle {

  Util.debugLevel = NferApp.config.getInt("debug.level")
  private[this] var started: Boolean = false

  private val applicationName = "nfer"

  implicit val actorSystem = ActorSystem(s"$applicationName-system")

  val timeout = Duration(NferApp.config.getLong("akka.timeout.ms"), MILLISECONDS) // maximum allowed timeout
  implicit val akkaTimeout = Timeout(timeout) // needed for `?` below

  // We're using the Akka reaper pattern
  val reaper = actorSystem.actorOf(Props(new Reaper), "Reaper")

  def loadActor(className:String, jarFile:Option[String]) = {
    Util.traceln(2, s"Loading $className...")

    val classLoader = jarFile match {
      case Some(jar) => new URLClassLoader (Array (new File (jar).toURI.toURL), getClass.getClassLoader)
      case None => getClass.getClassLoader
    }
    val testClass = classLoader.loadClass(className)
    val actorRef = actorSystem.actorOf(Props(testClass))
    Await.result(actorRef ? Ping, timeout)
    reaper ! Watch(actorRef)
  }

  def start() = {
    if (!started) {
      // yes, yes, not thread safe but that isn't the point - this runs single threaded
      started = true
      // Initialize the actors
      Util.traceln(0, s"Starting $applicationName")

      // load actors specified in the configuration files
      val actorsObject = NferApp.config.getObject("actors")
      for (key <- actorsObject.keySet) {
        val actorConfig = actorsObject.toConfig.getConfig(key)
        val className = actorConfig.getString("class")
        val jarFile = try {
          Some(actorConfig.getString("jar"))
        } catch {
          case exception:ConfigException => None
        }
        loadActor(className, jarFile)
      }

      Util.traceln(0, s"$applicationName is Ready")
    }
  }

  def stop() = {
    if (started) {
      Util.traceln(0, s"Shutting down $applicationName")
      // this is all handled by the reaper, just send it the message
      Await.result(reaper ? Shutdown, timeout)

      started = false
    }
  }

}

object NferApp {
  // load the default config from the built-in resources
  // user config can override properties using application.conf or system properties
  // Config objects are immutable
  val config:Config = ConfigFactory.load()
}