package gov.nasa.jpl.nfer.elastic

import gov.nasa.jpl.nfer.client._
import org.json4s._
import org.json4s.JsonDSL._
import org.json4s.jackson.JsonMethods._

/**
 * Created by seanmk on 11/30/15.
 */
class ElasticSearchQuery(client:ElasticSearchClient) {
  var kind:String = ""
  var query:JValue = parse("{}")

  def addQuery(toAdd:JValue) = {
    query = query merge toAdd
    this
  }

  def setKind(toSet:String) = {
    kind = toSet
    this
  }

  def getRawQuery:String = {
    compact(query)
  }

}

object ElasticSearchQuery {
  def fromEventMatcher(client:ElasticSearchClient, matcher:EpisodeMatcher):ElasticSearchQuery = {
    ElasticSearchQuery.matcherToTopic(new ElasticSearchQuery(client), matcher)
  }

  def matcherToTopic(query:ElasticSearchQuery, matcher:EpisodeMatcher):ElasticSearchQuery = {
    matcher match {
      case Kind(name, next) => matcherToTopic(query.setKind(name), next)
      case FieldEquals(field, value, next) =>
        matcherToTopic(query.addQuery(
          render("constant_score", ("filter", ("and", ("term", (field, value.toLowerCase)) :: Nil)))
        ), next)
      case FieldRange(field, from, to, next) =>
        matcherToTopic(query.addQuery(
          render("constant_score", ("filter", ("and", ("range", (field, ("gt", from.toString) ~ ("lt", to.toString))) :: Nil)))
        ), next)
      case FieldPrefix(field, prefix, next) =>
        matcherToTopic(query.addQuery(
          render("constant_score", ("filter", ("and", ("prefix", (field, prefix.toLowerCase)) :: Nil)))
        ), next)
      case DifferenceGTE(subtractFrom, toSubtract, gte, next) =>
        matcherToTopic(query.addQuery(
          render("constant_score", ("filter", ("and", ("script", ("script", s"""doc["$subtractFrom"].value - doc["$toSubtract"].value >= $gte""")) :: Nil)))
        ), next)
      case _ => query
    }
  }
}
