package gov.nasa.jpl.nfer.elastic

import com.sksamuel.elastic4s.{RichSearchHit, HitAs, ElasticClient}
import com.sksamuel.elastic4s.ElasticDsl._
import gov.nasa.jpl.nfer.lang.Episode
import gov.nasa.jpl.nfer.util.Util
import org.elasticsearch.action.search.SearchResponse
import org.json4s.NoTypeHints
import org.json4s.jackson.Serialization
import org.json4s.jackson.Serialization._

import scala.concurrent.duration._


/**
 * Created by seanmk on 11/12/15.
 */
class ElasticSearchResult[T <: Episode](client:ElasticClient, var response:SearchResponse)
                                         (implicit manifest:Manifest[T]) extends Iterator[T] {

  implicit val formats = Serialization.formats(NoTypeHints)
  val scrollKeepAlive = "1m"
  implicit val timeout = Duration(21474835000L, MILLISECONDS) // maximum allowed timeout

  implicit object IntervalHitAs extends HitAs[T] {
    override def as(hit: RichSearchHit): T = read[T](hit.sourceAsString)
  }

  // these maintain the current state
  private var iterator = response.as[T].iterator
  private var retrievedHits = response.getHits.getHits.size

  // the total matched number
  val count = response.getHits.getTotalHits

  override def hasNext:Boolean = {
    iterator.hasNext || (
      response.getScrollId != null &&
      retrievedHits < count
      )
  }

  override def next():T = {
    if (iterator.hasNext) {
      iterator.next()
    } else {
      Util.traceln(5, s"ElasticSearchResult Scrolling, retrieved $retrievedHits of $count")
      response = client.execute {
        searchScroll(response.getScrollId).keepAlive(scrollKeepAlive)
      }.await
      retrievedHits += response.getHits.getHits.size
      iterator = response.as[T].iterator
      iterator.next()
    }
  }
}
