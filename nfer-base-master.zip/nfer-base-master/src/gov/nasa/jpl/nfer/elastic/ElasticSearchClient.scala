package gov.nasa.jpl.nfer.elastic

import java.net.URI

import gov.nasa.jpl.nfer.client.{DatabaseClient, EpisodeMatcher}
import gov.nasa.jpl.nfer.lang.Episode
import gov.nasa.jpl.nfer.util.Util

import com.sksamuel.elastic4s._
import com.sksamuel.elastic4s.ElasticDsl._

import org.elasticsearch.common.settings.ImmutableSettings
import org.elasticsearch.search.sort.SortOrder
import org.json4s.NoTypeHints
import org.json4s.jackson.Serialization
import org.json4s.jackson.Serialization.write

import scala.concurrent.duration.Duration
import scala.concurrent.duration.MILLISECONDS


/**
 * Created by seanmk on 11/9/15.
 */
class ElasticSearchClient(uri:URI, indexName:String = "nfer", clusterName:String = "elasticsearch") extends DatabaseClient {
  implicit val timeout = Duration(21474835000L, MILLISECONDS) // maximum allowed timeout
  implicit val formats = Serialization.formats(NoTypeHints)

  val settings = ImmutableSettings.settingsBuilder().put("cluster.name", clusterName)
    .put("shield.user", "es_admin:nferadmin")
    .build()
  val client = ElasticClient.remote(settings, ElasticsearchClientUri(uri.toString))
  val scrollKeepAlive = "1m"
  val scrollLimit = 1000

  override def insert(episode: Episode): Unit = {
    // extract the type from the episode and write to the index
    // use json4s to get the JSON string here instead of trying to figure out the elastic4s api
    val toIndex = index into indexName / episode.kind source write(episode) id episode.id
    Util.traceln(6, s"Elasticsearch Client Index: ${toIndex.show}")
    client.execute {
      toIndex
    }
  }

  override def query[T <: Episode](matcher:EpisodeMatcher, sortField:Option[String] = None)(implicit manifest:Manifest[T]) = {
    val esQuery = ElasticSearchQuery.fromEventMatcher(this, matcher)
    Util.traceln(6, s"Querying ElasticSearch with ${esQuery.getRawQuery}")
    val toQuery = sortField match {
      case Some(sort) =>
        search in indexName / esQuery.kind rawQuery esQuery.getRawQuery sort fieldSort(sort).order(SortOrder.ASC) scroll scrollKeepAlive limit scrollLimit
      case None =>
        search in indexName / esQuery.kind rawQuery esQuery.getRawQuery scroll scrollKeepAlive limit scrollLimit
    }

    new ElasticSearchResult[T](client, client.execute { toQuery }.await)
  }

}

