package gov.nasa.jpl.nfer.lang

/**
 * Created by seanmk on 1/20/16.
 */
case class Event(val name:String, val start:Double, val map:Map[String,String]) extends Episode {
  // events are instantaneous
  val end = start
  val kind = Event.kind
}

object Event {
  val kind = "event"

  def unapply(values: Map[String, String]) = {
    Some(Event(values("name"), values("start").toDouble,
      values.filterKeys((key:String) => !Set("name", "start").contains(key) )))
  }
}