package gov.nasa.jpl.nfer.lang

/**
 * Created by seanmk on 10/20/15.
 *
 */
abstract class Episode {
  def start:Double
  def end:Double
  def name:String
  def kind:String
  def map:Map[String,String]
  // default implementation, must be unique
  def id:String = name + start

  // get the value of a declared field by name, default to empty
  def get(field:String):String = {
    try {
      this.getClass.getDeclaredMethod(field).invoke(this).toString
    } catch {
      // if there isn't a field, look in the value map
      case exception:NoSuchMethodException => map.getOrElse(field, "")
    }
  }
}

object Episode {
  implicit def ordering[E <: Episode] = new Ordering[E] {
    override def compare(a: E, b: E): Int = {
      // sort on start first, then end
      val first = a.start.compareTo(b.start)
      if (first != 0) first else a.end.compareTo(b.end)
    }
  }
}