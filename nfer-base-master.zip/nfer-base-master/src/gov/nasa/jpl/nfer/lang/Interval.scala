package gov.nasa.jpl.nfer.lang

/**
 * Created by seanmk on 10/23/15.
 */
case class Interval(val name:String, val start:Double, val end:Double,
                    val map:Map[String,String] = Map.empty[String,String]) extends Episode {
  val kind = Interval.kind
}

object Interval {
  val kind = "interval"

  def unapply(values: Map[String, String]) = {
    Some(Interval(values("name"), values("start").toDouble, values("end").toDouble,
      values.filterKeys((key:String) => !Set("name", "start", "end").contains(key) )))
  }
}
