package gov.nasa.jpl.nfer.lang

import java.util.Date

/**
 * Created by seanmk on 11/10/15.
 */
case class EndOfStream(name:String) extends Episode {
  override def kind = EndOfStream.kind
  val start:Double = new Date().getTime
  val end = start
  val map = Map.empty[String,String]
}

object EndOfStream {
  val kind = "eos"
}