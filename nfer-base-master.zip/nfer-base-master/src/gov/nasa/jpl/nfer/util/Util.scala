package gov.nasa.jpl.nfer.util

/**
 * User: rjoshi
 * Date: 2/11/13
 */
object Util {
  var debugLevel = -1

  def trace(l: Int, s: String) { if (l <= debugLevel) Console.out.print(s) }
  def traceln(l: Int, s: String) { if (l <= debugLevel) Console.out.println(s) }
}
