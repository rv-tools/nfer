package gov.nasa.jpl.nfer.persistence

import gov.nasa.jpl.nfer.client.{EpisodeMatcher, NferActor}
import gov.nasa.jpl.nfer.lang.{Event, Episode}
import gov.nasa.jpl.nfer.server.NferApp
import gov.nasa.jpl.nfer.util.Util

import scala.collection.JavaConversions._

/**
 * Created by seanmk on 11/4/15.
 */
class IntervalActor extends NferActor("IntervalActor") {
  // load the intervals we care about from the application config
  val intervalsObject = NferApp.config.getObject("intervals")

  val builders = intervalsObject.keySet.map(key => {
    val config = intervalsObject.toConfig.getConfig(key)
    val start = config.getString("start")
    val end = config.getString("end")
    val timeout = config.getDouble("timeout")
    new IntervalBuilder(key, start, end, timeout)
  })

  override def subscriptions = List(new EpisodeMatcher())

  override def receiveEpisode(episode:Episode) = episode match {
    case event: Event => {
      val result = builders.flatMap(builder => builder.add(event))

      // for now, publish if there is an interval returned by the builder
      for (interval <- result) this.publish(interval)
    }
    case _ => Util.traceln(0, "IntervalActor received an unexpected episode!")
  }

}
