package gov.nasa.jpl.nfer.persistence

import gov.nasa.jpl.nfer.lang.{Episode, Interval}
import gov.nasa.jpl.nfer.util.Util

import scala.collection.mutable


/**
 * Created by seanmk on 10/28/15.
 */
class IntervalBuilder(val intervalName:String, val startName:String, val endName:String, val maxDuration:Double) {
  private val orderNferInterval = Ordering[(Double, String)].on[(Episode, Option[Interval])](pair => (pair._1.start, pair._1.name))

  val startEvents = mutable.SortedSet[(Episode, Option[Interval])]()(orderNferInterval.reverse)
  val endEvents = mutable.SortedSet[(Episode, Option[Interval])]()(orderNferInterval)

  def add(event:Episode):Option[Interval] = {
    event.name match {
      case `startName` => {
        Util.traceln (1, s"Adding start episode ${event.name} at ${event.start}")

        val endIterator = endEvents.keysIteratorFrom(event, None)
        // find the next end episode
        val result:Option[Interval] = if (endIterator.hasNext) {
          val (end, intervalOption) = endIterator.next ()
          // if the two are within the max duration
          if (end.start < event.start + maxDuration) {
            intervalOption match {
              // if there is an interval associated with the end episode
              case Some(oldInterval) => {
                // and if the episode has a start time closer than the previous interval
                if (oldInterval.start < event.start) {
                  // then create a new interval
                  val newInterval = Interval (intervalName, event.start, end.start)

                  // put this interval in place of the old interval in the end list
                  endEvents.remove(end, intervalOption)
                  endEvents.add(end, Some(newInterval))

                  // it's an option, so Some
                  Some(newInterval)
                } else {
                  // otherwise don't create a new interval, we are waiting for another end episode
                  None
                }
              }
              case None => {
                // there is no existing interval, so create a new one
                val newInterval = Interval (intervalName, event.start, end.start)

                // add the interval to the end list too
                endEvents.remove(end, None)
                endEvents.add(end, Some(newInterval))

                // it's an option, so Some
                Some(newInterval)
              }
            }
          } else {
            None
          }
        } else {
          None
        }

        startEvents.add(event, result)
        result
      }
      case `endName` => {
        Util.traceln(1, s"Adding end episode ${event.name} at ${event.start}")

        val startIterator = startEvents.keysIteratorFrom(event, None)
        // find the prior start episode
        val result:Option[Interval] = if (startIterator.hasNext) {
          val (start, intervalOption) = startIterator.next()
          if (start.start > event.start - maxDuration) {
            intervalOption match {
              // if there is an interval associated with the end episode
              case Some(oldInterval) => {
                // and if the episode has an end time closer than the previous interval
                if (oldInterval.end > event.start) {
                  // then create a new interval
                  val newInterval = Interval (intervalName, start.start, event.start)

                  // put this interval in place of the old interval in the start list
                  startEvents.remove(start, intervalOption)
                  startEvents.add(start, Some(newInterval))

                  // it's an option, so Some
                  Some(newInterval)
                } else {
                  // otherwise don't create a new interval, we are waiting for another end episode
                  None
                }
              }
              case None => {
                // there is no existing interval, so create a new one
                val newInterval = Interval (intervalName, start.start, event.start)

                // add the interval to the start list too
                startEvents.remove(start, None)
                startEvents.add(start, Some(newInterval))

                // it's an option, so Some
                Some(newInterval)
              }
            }
          } else {
            None
          }
        } else {
          None
        }

        endEvents.add(event, result)
        result
      }
      case _ => None
    }
  }

  def findInterval(event:Episode):Option[Interval] = {
    Util.traceln(5, s"Finding intervals that overlap with ${event.name} at ${event.start}")

    val startIterator = startEvents.keysIteratorFrom(event, None)
    // find the prior start episode
    if (startIterator.hasNext) {
      val (start, intervalOption) = startIterator.next()
      intervalOption match {
        case Some(interval) =>
          if (interval.end > event.start)
            intervalOption
          else
            None
        case None => None
      }
    } else {
      None
    }
  }
}

