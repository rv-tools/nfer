package gov.nasa.jpl.nfer.persistence

import gov.nasa.jpl.nfer.client._
import gov.nasa.jpl.nfer.lang.{Event, Interval, Episode}
import gov.nasa.jpl.nfer.util.Util

/**
 * Created by seanmk on 11/9/15.
 */
class ElasticPersistenceActor extends NferActor("elasticPersistenceActor") {

  override def subscriptions = List(new EpisodeMatcher)

  override def receiveEpisode(episode:Episode) = episode match {
    case event:Event => database.insert(event)
    case interval:Interval => database.insert(interval)
    case _ => Util.traceln(2, s"ElasticPersistenceActor ignoring unexpected episode: ${episode.name}")
  }
}
