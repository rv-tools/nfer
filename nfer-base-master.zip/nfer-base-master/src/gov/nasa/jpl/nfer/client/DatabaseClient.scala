package gov.nasa.jpl.nfer.client

import gov.nasa.jpl.nfer.lang.Episode

/**
 * Created by seanmk on 1/21/16.
 */
trait DatabaseClient {
  def insert(episode: Episode): Unit
  def query[T <: Episode](matcher:EpisodeMatcher, sortField:Option[String] = None)(implicit manifest:Manifest[T]):Iterator[T]
}
