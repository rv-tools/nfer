package gov.nasa.jpl.nfer.client

/**
 * Created by seanmk on 10/21/15.
 */

case class NoCallbackException(message:String) extends Exception(message)
case class PubSubClientException(message:String) extends Exception(message)

trait PubSubClient {
  var callback:(Seq[EpisodeMatcher], String) => Unit = null

  def disconnect()
  def publish(matcher:EpisodeMatcher, message:String, qos:QOS.Value)
  def subscribe(matcher:EpisodeMatcher, qos:QOS.Value)
  def unsubscribe(matcher:EpisodeMatcher)
}

object QOS extends Enumeration {
  val AT_MOST_ONCE, AT_LEAST_ONCE, EXACTLY_ONCE = Value
}