package gov.nasa.jpl.nfer.client

import gov.nasa.jpl.nfer.lang._
import gov.nasa.jpl.nfer.util.Util

import org.json4s._
import org.json4s.jackson.Serialization.{read, write}

/**
 * Created by seanmk on 10/21/15.
 */
class EpisodeBroker(val client:PubSubClient) {
  client.callback = stringCallback
  var callback:(Episode) => Unit = null

  implicit val formats = new Formats {
    val dateFormat = DefaultFormats.lossless.dateFormat
    override val typeHints = ShortTypeHints(List(classOf[Episode], classOf[Interval],
      classOf[Event], classOf[EndOfStream]))
    override val typeHintFieldName = "kind"
  }

  private def stringCallback(matchers:Seq[EpisodeMatcher], message:String): Unit = {
    // deserialize the message from JSON into an episode, then call the user callback
    Util.traceln(5, s"Message received with length ${message.length}")
    Util.traceln(6, s"Message: [$message]")
    val readEvent:Option[Episode] = try {
      Some(read[Episode](message))
    } catch {
      case e:Exception => Util.traceln(-1, s"EXCEPTION IN READ: $e"); e.printStackTrace(); None
    }

    for (event <- readEvent) {
      // now that we have an episode, check against the passed matchers to make sure it satisfies
      // it must satisfy one of them to pass
      if (matchers.exists(matcher => matcher.test(event))) {
        callback(event)
      }
    }
  }

  def publish(episode:Episode) = {
    // serialize the episode to JSON, then publish the string
    val serialized = write(episode)
    client.publish(EpisodeMatcher(episode), serialized, QOS.EXACTLY_ONCE)
  }

  def subscribe(matcher:EpisodeMatcher) = {
    // set the QOS to exactly once
    client.subscribe(matcher, QOS.EXACTLY_ONCE)
  }

  def unsubscribe(matcher:EpisodeMatcher) = {
    // just unsubscribe
    client.unsubscribe(matcher)
  }
}
