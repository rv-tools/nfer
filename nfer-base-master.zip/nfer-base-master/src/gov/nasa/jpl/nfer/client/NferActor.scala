package gov.nasa.jpl.nfer.client

import java.net.URI

import akka.actor.Actor
import gov.nasa.jpl.nfer.elastic.ElasticSearchClient
import gov.nasa.jpl.nfer.lang.Episode
import gov.nasa.jpl.nfer.mqtt.MQTTClient
import gov.nasa.jpl.nfer.server.NferApp
import gov.nasa.jpl.nfer.util.Util

/**
 * Created by seanmk on 10/20/15.
 */
case object Ping
case object Ready

abstract class NferActor(val actorName:String) extends Actor {
  private val mqttBroker = new URI(s"tcp://${NferApp.config.getString("mqtt.broker")}")
  private val esServer = new URI(s"elasticsearch://${NferApp.config.getString("elasticsearch.host")}")
  // for now, don't persist clients
  private val persist = false
  private val mqttClient = new MQTTClient(appName = "nfer", broker = mqttBroker, clientId = actorName, persist = persist)
  private val broker = new EpisodeBroker(mqttClient)

  val database:DatabaseClient = new ElasticSearchClient(esServer)

  // set up the callback for the episode broker to pass its params asynchronously
  broker.callback = (episode:Episode) => {
    // we do this so that we can be sure the actors don't have code running in the same thread
    self ! episode
  }

  override def preStart() = {
    // subscribe to all the topics
    subscriptions.foreach(broker.subscribe)
  }

  override def postStop() = {
    // unsubscribe from all the topics
    subscriptions.foreach(broker.unsubscribe)
    // disconnect the client
    mqttClient.disconnect()
  }

  def publish(episode:Episode) = {
    broker.publish(episode)
  }

  def receive = {
    case Ping => sender ! Ready
    case event:Episode => {
      Util.traceln(5, s"Actor $actorName received an Event")
      receiveEpisode(event)
    }
    case _ => Util.traceln(0, s"Actor $actorName received something unexpected!")
  }

  def subscriptions:Seq[EpisodeMatcher]

  def receiveEpisode(episode:Episode)
}
