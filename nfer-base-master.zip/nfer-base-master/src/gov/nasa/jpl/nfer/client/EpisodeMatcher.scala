package gov.nasa.jpl.nfer.client

import gov.nasa.jpl.nfer.lang.Episode

/**
 * Created by seanmk on 11/24/15.
 */
class EpisodeMatcher {

  def kind(name:String):EpisodeMatcher = {
    Kind(name, this)
  }

  def fieldEquals(name:String, value:String):EpisodeMatcher = {
    FieldEquals(name, value, this)
  }

  // just shorthand for fieldEquals("name", x)
  def name(value:String):EpisodeMatcher = {
    FieldEquals("name", value, this)
  }

  def fieldRange(name:String, from:Double, to:Double):EpisodeMatcher = {
    FieldRange(name, from, to, this)
  }

  def fieldPrefix(name:String, prefix:String):EpisodeMatcher = {
    FieldPrefix(name, prefix, this)
  }

  def differenceGte(subtractFrom:String, toSubtract:String, gte:Double) = {
    DifferenceGTE(subtractFrom, toSubtract, gte, this)
  }

  def test(episode:Episode):Boolean = {
    this match {
      case Kind(name, next) => episode.kind == name && next.test(episode)
      case FieldEquals(field, value, next) => episode.get(field) == value && next.test(episode)
      case FieldRange(field, from, to, next) => episode.get(field).toDouble > from && episode.get(field).toDouble < to && next.test(episode)
      case FieldPrefix(field, prefix, next) => episode.get(field).startsWith(prefix) && next.test(episode)
      case DifferenceGTE(subtractFrom, toSubtract, gte, next) => episode.get(subtractFrom).toDouble - episode.get(toSubtract).toDouble >= gte && next.test(episode)
      case _ => true
    }
  }

  def kind:String = {
    this match {
      case Kind(name, next) => name
      case FieldEquals(_, _, next) => next.kind
      case FieldRange(_, _, _, next) => next.kind
      case FieldPrefix(_, _, next) => next.kind
      case DifferenceGTE(_, _, _, next) => next.kind
      case _ => "none"
    }
  }

  override def toString:String = {
    this match {
      case Kind(name, next) => s"Kind: $name, " + next.toString
      case FieldEquals(field, value, next) => s"[$field] = $value, " + next.toString
      case FieldRange(field, from, to, next) => s"$from <= $field <= $to, " + next.toString
      case FieldPrefix(field, prefix, next) => s"[$field] |= $prefix, " + next.toString
      case DifferenceGTE(subtractFrom, toSubtract, gte, next) => s"[$subtractFrom - $toSubtract] >= gte, " + next.toString
      case _ => ""
    }
  }
}

object EpisodeMatcher {
  // convenience function for generating a matcher from an Episode
  def apply(episode:Episode):EpisodeMatcher = {
    FieldEquals("name", episode.name, Kind(episode.kind, new EpisodeMatcher))
  }
}

case class Kind(name:String, next:EpisodeMatcher) extends EpisodeMatcher
case class FieldEquals(name:String, value:String, next:EpisodeMatcher) extends EpisodeMatcher
case class FieldRange(name:String, from:Double, to:Double, next:EpisodeMatcher) extends EpisodeMatcher
case class FieldPrefix(name:String, prefix:String, next:EpisodeMatcher) extends EpisodeMatcher
case class DifferenceGTE(subtractFrom:String, toSubtract:String, gte:Double, next:EpisodeMatcher) extends EpisodeMatcher