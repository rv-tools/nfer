package gov.nasa.jpl.nfer.mqtt

import java.net.URI
import java.nio.charset.StandardCharsets

import gov.nasa.jpl.nfer.client._
import gov.nasa.jpl.nfer.util.Util
import org.eclipse.paho.client.mqttv3._
import org.eclipse.paho.client.mqttv3.persist.MqttDefaultFilePersistence
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence

import scala.collection.mutable.ArrayBuffer

class MQTTClient(val appName:String, val broker:URI, val clientId:String, val persist:Boolean)
  extends MqttCallback with PubSubClient {

  val topics = new ArrayBuffer[MQTTTopic]()

  val client = try {
    Util.traceln(1, s"Connecting to MQTT broker ${broker.toString} with clientId $clientId")

    val persistence = if (persist) new MqttDefaultFilePersistence else new MemoryPersistence
    val client = new MqttClient(broker.toString, clientId, persistence)
    val options = new MqttConnectOptions
    // don't persist state across restarts for QoS
    // probably change this later, but for now it makes testing easier
    options.setCleanSession(true)
    client.connect(options)
    client.setCallback(this)
    client

  } catch {
    // wrap the MqttException in a more generic exception so the implementation is kept isolated
    case exception: MqttException =>
      throw new PubSubClientException("reason: [" + exception.getReasonCode + "] msg: [" + exception.getMessage +
        "] loc: [" + exception.getLocalizedMessage + "] cause: [" + exception.getCause + "] excep: [" + exception + "]")
  }

  def qosNumber(qos:QOS.Value):Int = {
    qos match {
      case QOS.AT_MOST_ONCE => 0
      case QOS.AT_LEAST_ONCE => 1
      case QOS.EXACTLY_ONCE => 2
    }
  }

  override def disconnect() = {
    try {
      Util.traceln(1, "Disconnecting from MQTT broker")

      client.disconnect()
      topics.clear()
    } catch {
      // wrap the MqttException in a more generic exception so the implementation is kept isolated
      case exception: MqttException =>
        throw new PubSubClientException("reason: [" + exception.getReasonCode + "] msg: [" + exception.getMessage +
          "] loc: [" + exception.getLocalizedMessage + "] cause: [" + exception.getCause + "] excep: [" + exception + "]")
    }
  }

  // publish method from the PubSubClient trait
  override def publish(matcher:EpisodeMatcher, message:String, qos:QOS.Value) = {
    val topic = MQTTTopic.fromEventMatcher(appName, matcher)
    // the final parameter is whether or not to set retain on the message
    try {
      Util.traceln(5, s"MQTT Publishing message on topic $topic with qos ${qosNumber(qos)}")
      Util.traceln(6, s"Message: [$message]")
      client.publish(topic.toString, message.getBytes(StandardCharsets.UTF_8), qosNumber(qos), false)
    } catch {
      // wrap the MqttException in a more generic exception so the implementation is kept isolated
      case exception: MqttException =>
        throw new PubSubClientException("reason: [" + exception.getReasonCode + "] msg: [" + exception.getMessage +
          "] loc: [" + exception.getLocalizedMessage + "] cause: [" + exception.getCause + "] excep: [" + exception + "]")
    }
  }

  // subscribe method from the PubSubClient trait
  override def subscribe(matcher:EpisodeMatcher, qos:QOS.Value) = {
    val topic = MQTTTopic.fromEventMatcher(appName, matcher)
    try {
      Util.traceln(2, s"MQTT Subscribing to topic $topic")
      topics += topic
      client.subscribe(topic.toString, qosNumber(qos))
    } catch {
      // wrap the MqttException in a more generic exception so the implementation is kept isolated
      case exception: MqttException =>
        throw new PubSubClientException("reason: [" + exception.getReasonCode + "] msg: [" + exception.getMessage +
          "] loc: [" + exception.getLocalizedMessage + "] cause: [" + exception.getCause + "] excep: [" + exception + "]")
    }
  }

  // unsubscribe method from the PubSubClient trait
  override def unsubscribe(matcher:EpisodeMatcher) = {
    val topic = MQTTTopic.fromEventMatcher(appName, matcher)
    try {
      Util.traceln(2, s"MQTT Unsubscribing from topic $topic")
      client.unsubscribe(topic.toString)
      topics -= topic
    } catch {
      // wrap the MqttException in a more generic exception so the implementation is kept isolated
      case exception: MqttException =>
        throw new PubSubClientException("reason: [" + exception.getReasonCode + "] msg: [" + exception.getMessage +
          "] loc: [" + exception.getLocalizedMessage + "] cause: [" + exception.getCause + "] excep: [" + exception + "]")
    }
  }

  // from the MqttCallback abstract class
  override def connectionLost(cause:Throwable) = {
    // handle lost connections to the broker
    // maybe try reconnecting?
    Util.traceln(0, s"MQTT Connection lost to broker")
  }

  // from the MqttCallback abstract class
  override def messageArrived(topic:String, message:MqttMessage) = {
    Util.traceln(5, s"MQTT Message arrived on topic $topic with qos ${message.getQos}")
    if (callback != null) {
      callback(topics.filter(mqttopic => mqttopic.test(topic)).map(mqttopic => mqttopic.unmatched),
        new String(message.getPayload, StandardCharsets.UTF_8))
    } else {
      throw new NoCallbackException(s"A message was received on topic $topic but no callback has been set")
    }
  }

  // from the MqttCallback abstract class
  override def deliveryComplete(token:IMqttDeliveryToken) = {
    // handle message delivery completion
    Util.traceln(5, "MQTT message delivery complete")
  }
}

