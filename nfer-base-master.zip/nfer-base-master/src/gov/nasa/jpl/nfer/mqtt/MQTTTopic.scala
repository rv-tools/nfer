package gov.nasa.jpl.nfer.mqtt

import gov.nasa.jpl.nfer.client._

/**
 * Created by seanmk on 10/22/15.
 */
class MQTTTopic(var application:String){
  var unmatched = new EpisodeMatcher
  var kind = "+"
  var name = "+"

  def setApplication(newApp:String) = {
    application = newApp
    this
  }

  def setKind(newKind:String) = {
    kind = newKind
    this
  }

  def setName(newName:String) = {
    name = newName
    this
  }

  def setMatch(matcher:EpisodeMatcher) = {
    unmatched = matcher
    this
  }

  override def toString:String = {
    s"$application/$kind/$name"
  }

  def test(topic:String):Boolean = {
    topic.matches(s"^$application/$kind/$name.*")
  }
}

object MQTTTopic {
  def fromEventMatcher(app:String, matcher:EpisodeMatcher):MQTTTopic = {
    MQTTTopic.matcherToTopic(new MQTTTopic(app), matcher)
  }

  def matcherToTopic(topic:MQTTTopic, matcher:EpisodeMatcher):MQTTTopic = {
    matcher match {
      case Kind(name, next) => matcherToTopic(topic.setKind(name), next)
      case FieldEquals("name", value, next) => matcherToTopic(topic.setName(value), next)
      case FieldEquals(field, value, next) => matcherToTopic(topic.setMatch(topic.unmatched.fieldEquals(field, value)), next)
      case FieldRange(field, from, to, next) => matcherToTopic(topic.setMatch(topic.unmatched.fieldRange(field, from, to)), next)
      case FieldPrefix(field, prefix, next) => matcherToTopic(topic.setMatch(topic.unmatched.fieldPrefix(field, prefix)), next)
      case DifferenceGTE(subtractFrom, toSubtract, gte, next) => matcherToTopic(topic.setMatch(topic.unmatched.differenceGte(subtractFrom, toSubtract, gte)), next)
      case _ => topic
    }
  }
}