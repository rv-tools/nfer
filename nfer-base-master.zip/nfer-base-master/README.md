# nfer
The Telemetry Inference Engine

## Getting Started

_This guide assumes you have Scala 2.11 installed and that Oracle JDK 8 is your system JVM._

1) Clone nfer into a working directory on your local machine.

```bash
$ git clone https://github.jpl.nasa.gov/seank/nfer.git
```

2) Compile nfer.  If you have IntelliJ IDEA you can import the project and build from there.  Otherwise, you can build with sbt on the command line.

```bash
$ cd nfer
$ sbt compile
```

3) Create the assembly JAR.  The IntelliJ IDEA project should have a run configuration called "Assemble JAR", but all it does is call sbt.

```bash
$ cd nfer
$ sbt assembly
```

4) Start nfer.

```bash
$ cd nfer
$ ./bin/nfer start
```

## Extending nfer

To add functionality to nfer, write classes which extend _gov.nasa.jpl.nfer.client.NferActor_.  To compile your project against nfer you first need to export nfer to your local ivy repository, then include it using sbt.  Once your code has been compiled against nfer, you must add configuration to nfer so it can be loaded.

1) From the nfer directory, export to your local Ivy repository.  The IntelliJ IDEA project should have a run configuration called "Publish to local Ivy cache", but all it does is call sbt.

```bash
$ cd nfer
$ sbt publish-local
```

2) **In your other project,** add the following library dependency.  The _Provided_ keyword tells sbt to not include the library in the assembly jar.

```
libraryDependencies += "gov.nasa.jpl" % "nfer_2.11" % "0.1" % Provided
```

3) Build an assembly jar of **your project**, just like you would build nfer.  See [SBT Assembly](https://github.com/sbt/sbt-assembly) instructions for how to add the assembly action to your project.

```bash
$ cd myNferExtension
$ sbt assembly
```

3) Add configuration to _conf/application.conf_ or create it if it doesn't exist.  You will add an entry under "actors" which specifies the fully qualified class name of your actor and the location of the jar on the filesystem.

```
actors {
  MyNferActorIdentifier {
    class = "gov.nasa.jpl.nfer.myNferExtension.MyNferActor"
    jar = "/home/username/workspace/myNferExtension/target/scala-2.11/myNferExtension-assembly-0.1.jar"
  }
}
```

4) Restart nfer

```bash
$ cd nfer
$ ./bin/nfer restart
```

## Running a local MQTT broker

If you don't want to use the broker specified in _resources/reference.conf_, you can run one locally without much difficulty.  The following instructions are for getting a local Mosquitto instance running and connecting nfer to it.

1) Download [Apache Mosquitto](http://mosquitto.org/download/), which will serve as the MQTT broker.  Many Linux distributions have packages for Mosquitto, OS X uses Homebrew and there are binary installers for Windows.

2) If you downloaded the Mosquitto source, build it.

```bash
$ tar -zxvf mosquitto-1.4.4.tar.gz
$ cd mosquitto-1.4.4
$ mkdir build
$ cd build
$ cmake ..
$ cmake --build .
```

3) Start the Mosquitto broker, using the config file in the nfer conf directory.  This will run in the foreground.

```bash
$ cd mosquitto-1.4.4/build/
$ ./src/mosquitto -c /home/user/path/to/nfer/conf/mosquitto.conf
```

4) Add configuration to _conf/application.conf_ to point to localhost

```
  mqtt.broker = "localhost:1883"
```

## Running a local ElasticSearch server

If you don't want to use the ES server specified in _resources/reference.conf_, you can run one locally without much difficulty.  The following instructions are for getting a local ElasticSearch instance running and connecting nfer to it.

1) Download [ElasticSearch 1.7.3](https://www.elastic.co/downloads/past-releases/elasticsearch-1-7-3).

2) Untar ElasticSearch, then install the _license_ and _shield_ plugins.

```bash
$ tar -zxvf elasticsearch-1.7.3.tar.gz
$ cd elasticsearch-1.7.3
$ ./bin/plugin -i elasticsearch/license/latest
$ ./bin/plugin -i elasticsearch/shield/latest
```

3) Still in the ElasticSearch directory, create the *es_admin* user, with the password *nferadmin*.  The password is checked into the code base, for now.

```bash
$ ./bin/shield/esusers useradd es_admin -r admin
```

**When it prompts for a password, type _nferadmin_, unless you change the password in ElasticSearchClient.scala** 

4) Run ElasticSearch.  It will run in the foreground.

```bash
$ ./bin/elasticsearch
```
    
5) Create the nfer index in ElasticSearch.  Provide the password when prompted.

```bash
$ curl -u es_admin -XPUT 'http://localhost:9200/nfer/'
```

6) Add configuration to _conf/application.conf_ to point to localhost

```
  elasticsearch.host = "localhost:9300"
```
